********************
*** Introduction ***
********************

The Consistency Analysis Tool (CAT) uses Maude's meta-programming features to automatically add the monitoring mechanism, automatically generates all the desired initial states, and performs the Maude model checking of consistency properties of distributed transaction systems (DTSs).

CAT takes as input:

- A Maude model of the DTS (e.g., "rola-mc.maude" in the folder "rola")
- The number of each of the following parameters: read-only, write-only, and read-write transactions; operations for each type of transaction; clients; servers; keys; and replicas per key. The tool analyzes the desired property for all initial states with the number of each of these parameters.
- The consistency property to be analyzed.

Given these inputs, CAT performs the following steps:

1. adds the monitoring mechanism to the user-provided system model;
2. generates all possible initial states with the user-provided number of the different parameters; and
3. executes the search command in Maude, from all generated initial states, for one reachable final state where the consistency property does not hold.

CAT outputs either “No solution,” meaning that all runs from all the given initial states satisfy the desired consistency property, or a counterexample (in Maude at the moment) showing a behavior that violates the property.


*************
*** Usage ***
*************

Run the script "run_cat.sh" with the following 13 parameters (in order):

- The folder of Maude source files that specify the distributed transaction system
- The main Maude file that specifies the system dynamics (to which the monitor will be added)
- The consistency property to be analyzed
- The number of each of the following parameters: read-only, write-only, and read-write transactions; operations for each type of transaction; clients; servers; keys; and replicas per key.

Example: ./run_cat.sh rola rola-mc.maude ra 0 0 3 0 0 2 2 2 2 1

The output, either "No solution" or a counterexmaple, will be stored, in this case, in "rola_copy/cat.out". The folder "rola_copy" additionally stores the generated system model and initial states.

Note that, under the hood, the script first runs the Maude tool (in the folder "Maude"), and then load "full-maude.maude" and "automonitor.maude" (CAT's algorithm), respectively, before loading the system model (e.g., "rola-mc.maude" in the foler "rola").


********************
*** Reproduction ***
********************

For ease of reproduction, we first interpret all model checking results (shown in Table 1, page 14, of the accompanying paper) as:

------------------------------------------------
|             A  B  C  D  E    F   G  H   I    |
|             RC RA CS UA NMSI PSI SI SER SSER |
| A RAMP-F    T  T  F  F  -    -   F  F   F    |
| B Faster    T  F  F  F  -    -   F  F   F    |
| C ROLA      T  T  T  T  -    -   F  F   F    |
| D Jessy     T  T  T  T  T    F   F  F   F    |
| E Walter    T  T  T  T  T    T   F  F   F    |
| F P-Store   T  T  T  T  T    T   T  T   F    |
------------------------------------------------

"T" and "F" stand for "tick" and "cross" in Table 1, respectively. We then use "(row_name,column_name)" to refer to the corresponding case. For example, (C,B) indicates modeling checking ROLA against RA.   

After a certain command is executed, the terminal will display either of the following two messages, after model checking is finished:

- "T - No counterexample found!"
- "F - Counterexample found!"

A detailed report (in particular, the concrete counterexample) can be found in the file "xxx_copy/cat.out". 

We provide two options for reproduction:

1. Evaluate our tool with the all-in-one script "./run_all.sh", which prints in termal all results one by one, followed by the above table. Alternatively, run with "./run_all.sh 2> /dev/null" to get rid of the "mkdir" warnings.

2. Evaluate our tool on a case basis to get quick answer for each case. We list the commands for reproducing all experimental results below (similarly, attach "2> /dev/null" at the end of each command to remove the "mkdir" warning):  

(A,A) : ./run_cat.sh ramp-f ramp-f-mc.maude rc   0 0 3 0 0 2 2 2 2 1
(A,B) : ./run_cat.sh ramp-f ramp-f-mc.maude ra   0 0 3 0 0 2 2 2 2 1
(A,C) : ./run_cat.sh ramp-f ramp-f-mc.maude cs   0 0 3 0 0 2 2 2 2 1
(A,D) : ./run_cat.sh ramp-f ramp-f-mc.maude ua   0 0 3 0 0 2 2 2 2 1
(A,E) : N/A
(A,F) : N/A
(A,G) : ./run_cat.sh ramp-f ramp-f-mc.maude si   0 0 3 0 0 2 2 2 2 1
(A,H) : ./run_cat.sh ramp-f ramp-f-mc.maude ser  0 0 3 0 0 2 2 2 2 1
(A,I) : ./run_cat.sh ramp-f ramp-f-mc.maude sser 0 0 3 0 0 2 2 2 2 1

(B,A) : ./run_cat.sh faster faster-mc.maude rc   0 0 3 0 0 2 2 2 2 1
(B,B) : ./run_cat.sh faster faster-mc.maude ra   1 1 0 2 2 0 2 2 2 1
(B,C) : ./run_cat.sh faster faster-mc.maude cs   0 0 4 0 0 2 2 2 2 1
(B,D) : ./run_cat.sh faster faster-mc.maude ua   0 0 4 0 0 2 2 2 2 1
(B,E) : N/A
(B,F) : N/A
(B,G) : ./run_cat.sh faster faster-mc.maude si   0 0 4 0 0 2 2 2 2 1
(B,H) : ./run_cat.sh faster faster-mc.maude ser  0 0 4 0 0 2 2 2 2 1
(B,I) : ./run_cat.sh faster faster-mc.maude sser 0 0 4 0 0 2 2 2 2 1

(C,A) : ./run_cat.sh rola   rola-mc.maude   rc   0 0 3 0 0 2 2 2 2 1
(C,B) : ./run_cat.sh rola   rola-mc.maude   ra   0 0 3 0 0 2 2 2 2 1
(C,C) : ./run_cat.sh rola   rola-mc.maude   cs   0 0 3 0 0 2 2 2 2 1
(C,D) : ./run_cat.sh rola   rola-mc.maude   ua   0 0 3 0 0 2 2 2 2 1
(C,E) : N/A
(C,F) : N/A
(C,G) : ./run_cat.sh rola   rola-mc.maude   si   0 0 3 0 0 2 2 2 2 1
(C,H) : ./run_cat.sh rola   rola-mc.maude   ser  0 0 3 0 0 2 2 2 2 1
(C,I) : ./run_cat.sh rola   rola-mc.maude   sser 0 0 3 0 0 2 2 2 2 1

(D,A) : ./run_cat.sh jessy  jessy-mc.maude  rc   0 0 3 0 0 2 2 2 2 1
(D,B) : ./run_cat.sh jessy  jessy-mc.maude  ra   0 0 3 0 0 2 2 2 2 1
(D,C) : ./run_cat.sh jessy  jessy-mc.maude  cs   0 0 3 0 0 2 2 2 2 1
(D,D) : ./run_cat.sh jessy  jessy-mc.maude  ua   0 0 3 0 0 2 2 2 2 1
(D,E) : ./run_cat.sh jessy  jessy-mc.maude  nmsi 0 0 3 0 0 1 2 2 2 1
(D,F) : ./run_cat.sh jessy  jessy-mc.maude  psi  0 0 3 0 0 2 2 2 2 2
(D,G) : ./run_cat.sh jessy  jessy-mc.maude  si   0 0 3 0 0 2 2 2 2 2
(D,H) : ./run_cat.sh jessy  jessy-mc.maude  ser  0 0 3 0 0 2 2 2 2 2
(D,I) : ./run_cat.sh jessy  jessy-mc.maude  sser 0 0 3 0 0 2 2 2 2 2

(E,A) : ./run_cat.sh walter walter-mc.maude rc   0 0 2 0 0 2 2 2 2 1
(E,B) : ./run_cat.sh walter walter-mc.maude ra   0 0 2 0 0 2 2 2 2 1
(E,C) : ./run_cat.sh walter walter-mc.maude cs   0 0 3 0 0 1 2 2 2 1
(E,D) : ./run_cat.sh walter walter-mc.maude ua   0 0 3 0 0 1 2 2 2 1
(E,E) : ./run_cat.sh walter walter-mc.maude nmsi 0 0 2 0 0 2 2 2 2 1
(E,F) : ./run_cat.sh walter walter-mc.maude psi  0 0 2 0 0 2 2 2 2 1
(E,G) : ./run_cat.sh walter walter-mc.maude si   0 0 2 0 0 2 2 2 2 1
(E,H) : ./run_cat.sh walter walter-mc.maude ser  0 0 2 0 0 2 2 2 2 1
(E,I) : ./run_cat.sh walter walter-mc.maude sser 0 0 2 0 0 2 2 2 2 1

(F,A) : ./run_cat.sh pstore gdur-mc.maude   rc   0 0 2 0 0 2 2 2 2 1
(F,B) : ./run_cat.sh pstore gdur-mc.maude   ra   0 0 2 0 0 2 2 2 2 1
(F,C) : ./run_cat.sh pstore gdur-mc.maude   cs   0 0 2 0 0 2 2 2 2 1
(F,D) : ./run_cat.sh pstore gdur-mc.maude   ua   0 0 2 0 0 2 2 2 2 1
(F,E) : ./run_cat.sh pstore gdur-mc.maude   nmsi 0 0 2 0 0 2 2 2 2 1
(F,F) : ./run_cat.sh pstore gdur-mc.maude   psi  0 0 2 0 0 2 2 2 2 1
(F,G) : ./run_cat.sh pstore gdur-mc.maude   si   0 0 2 0 0 2 2 2 2 1
(F,H) : ./run_cat.sh pstore gdur-mc.maude   ser  0 0 2 0 0 2 2 2 2 1
(F,I) : ./run_cat.sh pstore gdur-mc.maude   sser 1 1 0 1 1 0 2 2 1 1
