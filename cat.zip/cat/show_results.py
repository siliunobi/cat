import sys

final_res = sys.argv[1]

lines = open(final_res).readlines()

title=None
res=None

for line in lines:
    if line.startswith("-Run-"):
        if title:
            print("%s: %s" % (title, res))
        title = line[5:-1]
        res = ""
    else:
        if "N/A" in line:
            line = "-"
        elif "T" in line:
            line = "T"
        else:
            line = "F"
        res+=line+"\t"


print("%s: %s" % (title, res))
