rm final.out
echo "-Run- A RAMP-F" >> final.out

#(A,A) :
./run_cat.sh ramp-f ramp-f-mc.maude rc   0 0 3 0 0 2 2 2 2 1
#(A,B) : 
./run_cat.sh ramp-f ramp-f-mc.maude ra   0 0 3 0 0 2 2 2 2 1
#(A,C) : 
./run_cat.sh ramp-f ramp-f-mc.maude cs   0 0 3 0 0 2 2 2 2 1
#(A,D) : 
./run_cat.sh ramp-f ramp-f-mc.maude ua   0 0 3 0 0 2 2 2 2 1
#(A,E) : N/A
echo "N/A" >> final.out
#(A,F) : N/A
echo "N/A" >> final.out
#(A,G) : 
./run_cat.sh ramp-f ramp-f-mc.maude si   0 0 3 0 0 2 2 2 2 1
#(A,H) : 
./run_cat.sh ramp-f ramp-f-mc.maude ser  0 0 3 0 0 2 2 2 2 1
#(A,I) : 
./run_cat.sh ramp-f ramp-f-mc.maude sser 0 0 3 0 0 2 2 2 2 1

echo "-Run- B Faster" >> final.out
#(B,A) : 
./run_cat.sh faster faster-mc.maude rc   0 0 3 0 0 2 2 2 2 1
#(B,B) : 
./run_cat.sh faster faster-mc.maude ra   1 1 0 2 2 0 2 2 2 1
#(B,C) : 
./run_cat.sh faster faster-mc.maude cs   0 0 4 0 0 2 2 2 2 1
#(B,D) : 
./run_cat.sh faster faster-mc.maude ua   0 0 4 0 0 2 2 2 2 1
#(B,E) : N/A
echo "N/A" >> final.out
#(B,F) : N/A
echo "N/A" >> final.out
#(B,G) : 
./run_cat.sh faster faster-mc.maude si   0 0 4 0 0 2 2 2 2 1
#(B,H) : 
./run_cat.sh faster faster-mc.maude ser  0 0 4 0 0 2 2 2 2 1
#(B,I) : 
./run_cat.sh faster faster-mc.maude sser 0 0 4 0 0 2 2 2 2 1

echo "-Run- C ROLA" >> final.out
#(C,A) : 
./run_cat.sh rola   rola-mc.maude   rc   0 0 3 0 0 2 2 2 2 1
#(C,B) : 
./run_cat.sh rola   rola-mc.maude   ra   0 0 3 0 0 2 2 2 2 1
#(C,C) : 
./run_cat.sh rola   rola-mc.maude   cs   0 0 3 0 0 2 2 2 2 1
#(C,D) : 
./run_cat.sh rola   rola-mc.maude   ua   0 0 3 0 0 2 2 2 2 1
#(C,E) : N/A
echo "N/A" >> final.out
#(C,F) : N/A
echo "N/A" >> final.out
#(C,G) : 
./run_cat.sh rola   rola-mc.maude   si   0 0 3 0 0 2 2 2 2 1
#(C,H) : 
./run_cat.sh rola   rola-mc.maude   ser  0 0 3 0 0 2 2 2 2 1
#(C,I) : 
./run_cat.sh rola   rola-mc.maude   sser 0 0 3 0 0 2 2 2 2 1

echo "-Run- D Jessy" >> final.out
#(D,A) : 
./run_cat.sh jessy  jessy-mc.maude  rc   0 0 3 0 0 2 2 2 2 1
#(D,B) : 
./run_cat.sh jessy  jessy-mc.maude  ra   0 0 3 0 0 2 2 2 2 1
#(D,C) : 
./run_cat.sh jessy  jessy-mc.maude  cs   0 0 3 0 0 2 2 2 2 1
#(D,D) : 
./run_cat.sh jessy  jessy-mc.maude  ua   0 0 3 0 0 2 2 2 2 1
#(D,E) : 
./run_cat.sh jessy  jessy-mc.maude  nmsi 0 0 3 0 0 1 2 2 2 1
#(D,F) : 
./run_cat.sh jessy  jessy-mc.maude  psi  0 0 3 0 0 2 2 2 2 2
#(D,G) : 
./run_cat.sh jessy  jessy-mc.maude  si   0 0 3 0 0 2 2 2 2 2
#(D,H) : 
./run_cat.sh jessy  jessy-mc.maude  ser  0 0 3 0 0 2 2 2 2 2
#(D,I) : 
./run_cat.sh jessy  jessy-mc.maude  sser 0 0 3 0 0 2 2 2 2 2

echo "-Run- E Walter" >> final.out
#(E,A) : 
./run_cat.sh walter walter-mc.maude rc   0 0 2 0 0 2 2 2 2 1
#(E,B) : 
./run_cat.sh walter walter-mc.maude ra   0 0 2 0 0 2 2 2 2 1
#(E,C) : 
./run_cat.sh walter walter-mc.maude cs   0 0 3 0 0 1 2 2 2 1
#(E,D) : 
./run_cat.sh walter walter-mc.maude ua   0 0 3 0 0 1 2 2 2 1
#(E,E) : 
./run_cat.sh walter walter-mc.maude nmsi 0 0 2 0 0 2 2 2 2 1
#(E,F) : 
./run_cat.sh walter walter-mc.maude psi  0 0 2 0 0 2 2 2 2 1
#(E,G) :
./run_cat.sh walter walter-mc.maude si   0 0 2 0 0 2 2 2 2 1
#(E,H) : 
./run_cat.sh walter walter-mc.maude ser  0 0 2 0 0 2 2 2 2 1
#(E,I) : 
./run_cat.sh walter walter-mc.maude sser 0 0 2 0 0 2 2 2 2 1

echo "-Run- F P-Store" >> final.out
#(F,A) : 
./run_cat.sh pstore gdur-mc.maude   rc   0 0 2 0 0 2 2 2 2 1
#(F,B) : 
./run_cat.sh pstore gdur-mc.maude   ra   0 0 2 0 0 2 2 2 2 1
#(F,C) : 
./run_cat.sh pstore gdur-mc.maude   cs   0 0 2 0 0 2 2 2 2 1
#(F,D) : 
./run_cat.sh pstore gdur-mc.maude   ua   0 0 2 0 0 2 2 2 2 1
#(F,E) : 
./run_cat.sh pstore gdur-mc.maude   nmsi 0 0 2 0 0 2 2 2 2 1
#(F,F) : 
./run_cat.sh pstore gdur-mc.maude   psi  0 0 2 0 0 2 2 2 2 1
#(F,G) : 
./run_cat.sh pstore gdur-mc.maude   si   0 0 2 0 0 2 2 2 2 1
#(F,H) : 
./run_cat.sh pstore gdur-mc.maude   ser  0 0 2 0 0 2 2 2 2 1
#(F,I) : 
./run_cat.sh pstore gdur-mc.maude   sser 1 1 0 1 1 0 2 2 1 1

python show_results.py final.out
